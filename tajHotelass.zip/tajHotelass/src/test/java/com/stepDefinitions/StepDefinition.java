package com.stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.utility.StartClass;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class StepDefinition {
	public WebDriver driver;
	StartClass sc = new StartClass(driver);

	@Given("Open the Browser")
	public void open_the_browser() {
		sc.startBrowser();
		System.out.println("Chrome");
	}

	@And("Enter into the {string} Website")
	public void enter_into_the_website(String site) {
		sc.getUrl(site);
		System.out.println(site);
	}

	@And("user need to click on search icon")
	public void user_need_to_click_on_search_icon() {
		sc.search().click();
		System.out.println("Icon");
	}

	@And("user need to type {string} in search bar")
	public void user_need_to_type_in_search_bar(String city) {
		sc.searchIcon(city).sendKeys(city);
		sc.enter();
		System.out.println(city);
	}

	@And("verify the The Taj Mahal Palace keyword in that page")
	public void verify_the_london_keyword_in_that_page() {
		Assert.assertEquals(sc.verify().getText(), "The Taj Mahal Palace");
		System.out.println("Verification Done");
	}

	@Then("close the website")
	public void close_the_website() {
		sc.quit();
		System.out.println("Closed");
	}

	@Given("user need to click on View Details under Member Exclusive Offer")
	public void user_need_to_click_on_view_details_under_member_exclusive_offer()
	{
		sc.memberExclusive().click();
		System.out.println("Memeber Exclusive");
	}

	@Given("verify the 15 Savings text in that page")
	public void verify_the_savings_text_in_that_page()
	{
		Assert.assertTrue(sc.verify().getText().contains("15% Saving"));
		System.out.println("verified done");
	}

	@Given("user need to click Taj Magazine")
	public void user_need_to_click_taj_magazine()
	{
		sc.footer().click();
		System.out.println("Footer");
	}

	@Given("verify the PICKLE STORIES FROM MY LIFE keyword in that page")
	public void verify_the_pickle_stories_from_my_life_keyword_in_that_page()
	{
		Assert.assertTrue(sc.verifyFooter().getText().contains("PICKLE STORIES FROM MY LIFE"));
		System.out.println("Verified");
	}

}
