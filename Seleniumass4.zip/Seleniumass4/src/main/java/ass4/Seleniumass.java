package ass4;


	import java.util.List;
	import org.apache.logging.log4j.LogManager;
	import org.apache.logging.log4j.Logger;
	import org.openqa.selenium.By;
	import org.openqa.selenium.NoSuchElementException;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.annotations.Test;
	
	public class Seleniumass
	{
	    static Logger log=LogManager.getLogger(Seleniumass.class.getName());
	    @Test
	    public void page()
	    {
	        String price;
	        System.setProperty("webdriver.chrome.driver",".//driver//chromedriver.exe");
	        WebDriver driver=new ChromeDriver();
	        driver.get("https://www.amazon.com/dp/B07XJ8C8F5");
	        //Printing Product Title Using Class
	        System.out.print(driver.findElement(By.id("productTitle")).getText());
	        try {
	            price=driver.findElement(By.id("priceblock_ourprice")).getText();
	        }
	        catch(NoSuchElementException e)
	        {
	           price=null;  
	        }
	        System.out.println("\n Price of the product : "+price);
	        List<WebElement> links=driver.findElements(By.tagName("a"));

	        for(int i=0;i<links.size();i++)
	        {
	            WebElement E1= links.get(i);
	            String url= E1.getAttribute("href");
	            log.info(" links : "+url);
	           
	            
	        }
	        //OUTPUT ARE STORE IN OUTPUT_PRINT FOLDER IN PROJECT 
	        log.info("Image URL : ");
	        log.info("url : "+driver.findElement(By.cssSelector("img[style=\"max-width:160px;max-height:160px\"]")).getAttribute("src"));
	      
	    }
	   

}

