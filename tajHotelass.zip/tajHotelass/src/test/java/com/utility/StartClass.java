package com.utility;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class StartClass
{
	public WebDriver driver;
	public StartClass(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void startBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}
	public void getUrl(String site)
	{
		driver.get(site);
	}
	public WebElement search()
	{
		return driver.findElement(By.xpath("//input[@name='searchbar-global']"));
	}
	public WebElement searchIcon(String city)
	{
		return driver.findElement(By.xpath("//input[@name='searchbar-global']"));
		
	}
	public void enter()
	{
		
		driver.findElement(By.xpath("//input[@name='searchbar-global']")).sendKeys(Keys.DOWN);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		String script="return document.getElementByxpath(\"//input[@name='searchbar-global']\").value;";
		String text=(String)js.executeScript(script);
		int i=0;
		while(!text.equalsIgnoreCase("The Taj Mahal Palace Mumbai"))
		{
			i++;
			driver.findElement(By.xpath("//input[@name='searchbar-global']")).sendKeys(Keys.DOWN);
			text=(String)js.executeScript(script);
			if(i>5)
			{
				break;
			}
		}
		if(i>5)
		{
			System.out.println("Element Not There in list");
		}
		else
		{
			System.out.println("Element Found");
		}
		
	}
	public WebElement verify()
	{
		return driver.findElement(By.cssSelector("h1[class*=ho-header']"));//verify taj mahal
	}
	public void quit()
	{
		driver.quit();
	}
	
	public WebElement memberExclusive()
	{
		return driver.findElement(By.xpath("/html/body/div[3]/div[2]/main/div[3]/div/div/div[3]/div/div[2]/div/div[2]/div/div[1]/div/div[3]/div[2]/button"));
	}
	public WebElement Verify()
	{
		return driver.findElement(By.xpath("/html/body/div[1]/div[2]/main/div[3]/div/div/div[5]/div/div/div[1]/div[3]/div[2]/div[1]/div[2]"));
	}
	public WebElement footer()
	{
		return driver.findElement(By.linkText("Taj Magazine"));
	}
	public WebElement verifyFooter()
	{
		return driver.findElement(By.xpath("/html/body/div[1]/div[2]/main/div[3]/div/div/div/div[1]/div/div[5]/div/div/div[1]/div/div/div[2]/div/div[1]/div[2]/div/h3/i"));
	}
	
}
